#import <Flutter/Flutter.h>

@interface OpenVPNFlutterPlugin : NSObject<FlutterPlugin>
@end
