## 0.1.0

* Fixed android connection state.

## 0.0.9

* Remove unused code.

## 0.0.7

* Remove unused permission.

## 0.0.4

* Add example.

## 0.0.3

* Initial Open Source release.
