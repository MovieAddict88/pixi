#include <string>

namespace wireguard_flutter
{

    std::wstring WriteConfigToTempFile(std::string config);

}
