import 'package:flutter/material.dart';

class AppColors{
  static const Color appBgColor = Color(0xff00020d);
  static const Color appPrimaryColor = Colors.blue;
}