import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:pixi_vpn/screen/home/v2_home_screen.dart';
import 'package:pixi_vpn/screen/auth/signin_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../controller/general_setting_controller.dart';
import '../data/datasource/remote/dio/dio_client.dart';
import '../data/model/base_model/api_response.dart';
import '../data/repository/auth_repo.dart';
import '../screen/auth/reset_password_screen.dart';
import '../screen/home/open_vpn_home_screen.dart';
import '../screen/home/wg_home_screen.dart';

class AuthController extends GetxController {
  final DioClient dioClient;
  final AuthRepo authRepo;

  AuthController({
    required this.authRepo,
    required this.dioClient,
  });

  bool isLoadingLogin = false;
  bool isLoadingRegister = false;
  bool isLoadingForget = false;
  bool isLoadingReset = false;

  var rememberMe = false.obs;

  void _showToast({required String msg, required bool isSuccess}) {
    Fluttertoast.showToast(
      msg: msg,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 1,
      backgroundColor: isSuccess ? Colors.green : Colors.red,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }

  // ================= REGISTER =================

  register({
    required String email,
    required String name,
    required String password,
  }) async {
    isLoadingRegister = true;
    update();

    try {
      final ApiResponse apiResponse = await authRepo.register(
        name: name,
        email: email,
        password: password,
      );

      final response = apiResponse.response;

      if (response != null && response.statusCode == 201) {
        final Map<String, dynamic> data = response.data;
        final String? token = data["token"];
        final String? message = data["massage"]; // spelling mistake? Should it be "message"?

        final success = message == "User Signed Up";

        _showToast(
          msg: success ? message! : "Something went wrong! Or Invalid user data",
          isSuccess: success,
        );

        if (success && token != null && token.isNotEmpty) {
          await authRepo.saveUserToken(token);
          return apiResponse.response!.statusCode;
        }
      } else {
        _showToast(msg: "Something went wrong! Or Invalid user data", isSuccess: false);
      }

    } catch (e) {
      _showToast(msg: "Something went wrong! Or Invalid user data", isSuccess: false);
    } finally {
      isLoadingRegister = false;
      update();
    }
  }

  // ================= LOGIN =================

  Future<void> login({
    required String email,
    required String password,
    required String deviceId,
  }) async {
    isLoadingLogin = true;
    update();

    try {
      final ApiResponse apiResponse = await authRepo.login(
        email: email,
        password: password,
        deviceId: deviceId,
      );

      final response = apiResponse.response;

      if (response != null && response.statusCode == 200) {
        final Map<String, dynamic> data = response.data;
        final String? token = data["token"];
        final String? message = data["message"];

        final success = message == "Login successful";

        _showToast(
          msg: success ? message! : "Something went wrong! Or Invalid user data",
          isSuccess: success,
        );

        if (success && token != null && token.isNotEmpty) {
          await authRepo.saveUserToken(token);

          // Navigate based on selected protocol
          await _navigateToSelectedProtocol();
        }
      } else {
        _showToast(msg: "Something went wrong! Or Invalid user data", isSuccess: false);
      }
    } catch (e) {
      _showToast(msg: "Something went wrong! Or Invalid user data", isSuccess: false);
    } finally {
      isLoadingLogin = false;
      update();
    }
  }

  forgetPassword({dynamic email}) async {
    isLoadingForget = true;
    update();

    try {
      ApiResponse apiResponse = await authRepo.forgetPassword(email: email);

      if (apiResponse.response != null && apiResponse.response!.statusCode == 200) {
        isLoadingForget = false;

        _showToast(msg: "Please check your email Inbox", isSuccess: true);

        Get.to(()=> const ResetPasswordScreen(),transition: Transition.leftToRight);

      } else {
        isLoadingForget = false;
        update();
        if (apiResponse.response != null) {
          // If the status code is not 200, show an error
          _showToast(msg: "Something went wrong! Or Invalid user data", isSuccess: false);

        } else {
          isLoadingForget = false;
          // If there's no response or network error
          _showToast(msg: "Something went wrong! Or Invalid user data", isSuccess: false);
        }
      }

    } catch (e) {
      // General catch block for any unexpected errors
      isLoadingForget = false;
      update();
      if (kDebugMode) {
        print("Unexpected error: $e");
      }
      _showToast(msg: "Something went wrong! Or Invalid user data", isSuccess: false);
    }

    update();
  }

  resetPassword({dynamic email,dynamic token, dynamic password, dynamic confirmPassword}) async {
    isLoadingReset = true;
    update();

    try {
      ApiResponse apiResponse = await authRepo.resetPassword(email: email,token: token,password: password,confirmPassword: confirmPassword);

      if (apiResponse.response != null && apiResponse.response!.statusCode == 200) {
        isLoadingReset = false;
        _showToast(msg: "Password reset successful", isSuccess: true);

        Get.to(()=> const SignInScreen(),transition: Transition.leftToRight);

      } else {
        isLoadingReset = false;
        update();
        if (apiResponse.response != null) {
          // If the status code is not 200, show an error
          _showToast(msg: "Something went wrong! Or Invalid user data", isSuccess: false);
        } else {
          isLoadingReset = false;
          // If there's no response or network error
          _showToast(msg: "Something went wrong! Or Invalid user data", isSuccess: false);
        }
      }

    } catch (e) {
      // General catch block for any unexpected errors
      isLoadingReset = false;
      update();
      if (kDebugMode) {
        print("Unexpected error: $e");
      }
      _showToast(msg: "Something went wrong! Or Invalid user data", isSuccess: false);
    }

    update();
  }


  // ================= TOKEN =================

  Future<String> getUserToken() async {
    final token = await authRepo.getUserToken();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      update();
    });
    return token;
  }

  Future<void> removeUserToken() async {
    await authRepo.removeUserToken();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      update();
    });
  }

  Future<String> getAuthToken() async {
    final token = await authRepo.getAuthToken();
    dioClient.updateHeader(token, '');
    WidgetsBinding.instance.addPostFrameCallback((_) {
      update();
    });
    return token;
  }

  // ================= NAVIGATION =================

  Future<void> _navigateToSelectedProtocol() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? selectedProtocol = prefs.getString('selected_vpn_protocol');

    // If user hasn't selected a protocol, use default from API
    if (selectedProtocol == null || selectedProtocol.isEmpty) {
      final generalSettingController = Get.find<GeneralSettingController>();
      final generalData = generalSettingController.appGeneralData;

      if (generalData != null) {
        String defaultProtocol = generalData['default_protocol'] ?? 'v2ray';

        // Navigate based on default protocol from API
        switch (defaultProtocol.toLowerCase()) {
          case 'openvpn':
            Get.offAll(() => const OpenVpnHomeScreen(), transition: Transition.leftToRight);
            return;
          case 'v2ray':
            Get.offAll(() => const V2HomeScreen(), transition: Transition.leftToRight);
            return;
          case 'wireguard':
            Get.offAll(() => const WGHomeScreen(), transition: Transition.leftToRight);
            return;
          default:
            Get.offAll(() => const V2HomeScreen(), transition: Transition.leftToRight);
            return;
        }
      } else {
        // If API data is not available, default to V2Ray
        Get.offAll(() => const V2HomeScreen(), transition: Transition.leftToRight);
        return;
      }
    }

    // User has selected a protocol locally, use that
    if (selectedProtocol == 'openvpn') {
      Get.offAll(() => const OpenVpnHomeScreen(), transition: Transition.leftToRight);
    } else if (selectedProtocol == 'v2ray') {
      Get.offAll(() => const V2HomeScreen(), transition: Transition.leftToRight);
    } else if (selectedProtocol == 'wireguard') {
      Get.offAll(() => const WGHomeScreen(), transition: Transition.leftToRight);
    } else {
      // Automatic (Recommended) or any other value - use default from API
      final generalSettingController = Get.find<GeneralSettingController>();
      final generalData = generalSettingController.appGeneralData;

      if (generalData != null) {
        String defaultProtocol = generalData['default_protocol'] ?? 'v2ray';

        switch (defaultProtocol.toLowerCase()) {
          case 'openvpn':
            Get.offAll(() => const OpenVpnHomeScreen(), transition: Transition.leftToRight);
            return;
          case 'v2ray':
            Get.offAll(() => const V2HomeScreen(), transition: Transition.leftToRight);
            return;
          case 'wireguard':
            Get.offAll(() => const WGHomeScreen(), transition: Transition.leftToRight);
            return;
          default:
            Get.offAll(() => const V2HomeScreen(), transition: Transition.leftToRight);
            return;
        }
      } else {
        Get.offAll(() => const V2HomeScreen(), transition: Transition.leftToRight);
      }
    }
  }
}
